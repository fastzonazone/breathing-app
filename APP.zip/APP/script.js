{\rtf1\ansi\ansicpg1252\cocoartf2761
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\paperw11900\paperh16840\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 document.addEventListener('DOMContentLoaded', () => \{\
    const circle = document.getElementById('circle');\
    const instruction = document.getElementById('instruction');\
    const startButton = document.getElementById('startButton');\
    const sessionCount = document.getElementById('sessionCount');\
    const inhaleTimeInput = document.getElementById('inhaleTime');\
    const exhaleTimeInput = document.getElementById('exhaleTime');\
\
    // Carica il numero di sessioni completate da localStorage\
    let sessionCounter = parseInt(localStorage.getItem('sessionCounter')) || 0;\
    sessionCount.textContent = sessionCounter;\
\
    startButton.addEventListener('click', () => \{\
        sessionCounter++;\
        sessionCount.textContent = sessionCounter;\
        localStorage.setItem('sessionCounter', sessionCounter); // Salva in localStorage\
\
        const inhaleTime = parseInt(inhaleTimeInput.value) * 1000; // converti in millisecondi\
        const exhaleTime = parseInt(exhaleTimeInput.value) * 1000; // converti in millisecondi\
\
        startBreathingExercise(inhaleTime, exhaleTime);\
    \});\
\
    function startBreathingExercise(inhaleTime, exhaleTime) \{\
        instruction.textContent = "Inspira...";\
        circle.style.transform = "scale(1.5)";\
\
        setTimeout(() => \{\
            instruction.textContent = "Espira...";\
            circle.style.transform = "scale(1)";\
\
            setTimeout(() => \{\
                startBreathingExercise(inhaleTime, exhaleTime);\
            \}, exhaleTime); // tempo di espirazione\
        \}, inhaleTime); // tempo di inspirazione\
    \}\
\});\
}